@echo off
echo Starting Netting Broker AI Runner...
node run.js
pause
